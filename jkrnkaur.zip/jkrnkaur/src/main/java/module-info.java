module com.example.jkrnkaur {
    requires java.sql;
    requires javafx.controls;
    requires javafx.fxml;

    opens com.example.jkrnkaur to javafx.fxml;
    exports com.example.jkrnkaur;
}
